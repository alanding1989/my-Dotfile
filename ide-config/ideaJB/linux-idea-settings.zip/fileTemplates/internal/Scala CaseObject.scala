#if ((${PACKAGE_NAME} && ${PACKAGE_NAME} != ""))package ${PACKAGE_NAME} #end
#parse("File Header.java")

/**
 *  @Author      :  AlanDing
 *  @Time        :  ${DATE} ${TIME}
 *  @File        :  ${NAME}.java
 *  @Description :   
 */
 
case object ${NAME}

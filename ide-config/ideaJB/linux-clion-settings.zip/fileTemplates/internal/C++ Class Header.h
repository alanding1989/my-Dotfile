// ${NAME}.hpp //

/**
 * File Name    : ${NAME}
 * Author       : AlanDing
 * Created Time : ${DATE} ${TIME}
 * Description  :
 */

#[[#ifndef]]# ${INCLUDE_GUARD}
#[[#define]]# ${INCLUDE_GUARD}


${NAMESPACES_OPEN}

class ${NAME}
{
private:

public:
    
};

${NAMESPACES_CLOSE}

#[[#endif]]# //${INCLUDE_GUARD}

